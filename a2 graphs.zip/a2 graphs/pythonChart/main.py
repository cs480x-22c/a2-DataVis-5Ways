# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import matplotlib.axes as ax


headers = ['Weight', 'MPG']
df = pd.read_csv('cars.csv')
MPG = df.MPG
Weight = df.Weight
Manufacturer = df.Manufacturer
ManuC = []
for i in Manufacturer:
    if i == "ford":
        ManuC.append("lime")
    if i == "toyota":
        ManuC.append("magenta")
    if i == "mercedes":
        ManuC.append("blue")
    if i == "honda":
        ManuC.append("green")
    if i == "bmw":
        ManuC.append("red")


# scatter plot with scatter() function
plt.scatter(Weight, MPG,
            s=(Weight/12), c=ManuC, alpha=0.5)
plt.grid()
plt.xlabel("Weight", size=16)
plt.ylabel("MPG", size=16)
plt.xlim(1400,5000)
plt.ylim(8,50)
plt.show()

